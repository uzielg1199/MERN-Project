{/* <DeleteButton 
author = {author}
changeStyle = {false}
removeAuthorFromList = {removeAuthorFromList} */}